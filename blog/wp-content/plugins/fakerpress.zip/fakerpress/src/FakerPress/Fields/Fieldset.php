<?php
namespace FakerPress\Fields;

class Fieldset extends Fieldset_Abstract {

}