<?php
$field = $this->get( 'field' );

$this->render( 'components/container/start' );

var_dump( $field );

$this->render( 'components/container/end' );
